# Bulletin de moyenne — avec assistant IA

Site de calcul de moyenne pondérée, avec un assistant IA (Gemini) qui
répond aux questions sur le bulletin. La clé API Gemini reste côté
serveur : elle n'est jamais envoyée au navigateur.

## Structure

- `public/index.html` — le site (calcul de moyenne + widget de chat)
- `server.js` — serveur Express : sert le site et relaie les questions
  vers l'API Gemini via `POST /api/chat`
- `package.json` — dépendances

## Déploiement sur Render

1. Poussez ce dossier sur un dépôt Git (GitHub/GitLab) relié à Render.
2. Sur Render : **New +** → **Web Service**, sélectionnez le dépôt.
3. Configuration :
   - **Build command** : `npm install`
   - **Start command** : `npm start`
   - **Environment** : Node
4. Dans **Environment → Environment Variables**, ajoutez :
   - `GEMINI_API_KEY` = votre clé API Gemini (depuis Google AI Studio)
   - `GEMINI_MODEL` = `gemini-3.5-flash` (optionnel, c'est la valeur par
     défaut — voir la note ci-dessous)
5. Déployez. Render fournit automatiquement `PORT`.

## À propos du modèle

Il n'existe pas de modèle nommé « Gemini 3.0 Flash » chez Google : la
famille actuelle est **Gemini 3 Flash** (preview), puis **Gemini 3.1
Flash-Lite**, puis **Gemini 3.5 Flash** (le Flash stable le plus récent
à ce jour). Le serveur utilise `gemini-3.5-flash` par défaut ; changez
la variable `GEMINI_MODEL` si vous préférez `gemini-3-flash-preview`
ou un autre modèle.

## Test en local

```bash
npm install
export GEMINI_API_KEY="votre_clé"
npm start
# puis ouvrir http://localhost:3000
```
