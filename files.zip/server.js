// server.js
// Sert le site statique (index.html) et expose /api/chat qui relaie les
// messages vers l'API Gemini. La clé API reste côté serveur (variable
// d'environnement Render), jamais exposée au navigateur.

const express = require('express');
const path = require('path');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const GEMINI_MODEL = process.env.GEMINI_MODEL || 'gemini-3.5-flash';
const GEMINI_URL = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`;

const SYSTEM_INSTRUCTION = `Tu es l'assistant du site "Bulletin de moyenne".
Tu aides l'utilisateur à comprendre le calcul de sa moyenne pondérée
(note x coefficient, somme divisée par la somme des coefficients),
à interpréter les appréciations (Excellent, Très bien, Bien, Assez bien,
Peut mieux faire, Insuffisant) et à estimer quelle note il lui faudrait
dans une matière pour atteindre un objectif de moyenne. Réponds en
français, de façon brève et claire. Si la question sort du cadre du
calcul de moyenne, réponds-y quand même brièvement mais reste concis.`;

app.post('/api/chat', async (req, res) => {
  try {
    if (!GEMINI_API_KEY) {
      return res.status(500).json({ error: "Clé API Gemini manquante côté serveur (variable GEMINI_API_KEY)." });
    }

    const { message, history } = req.body;
    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: "Le champ 'message' est requis." });
    }

    // history: [{role: 'user'|'model', text: '...'}, ...] envoyé par le front
    const contents = Array.isArray(history)
      ? history.map(h => ({ role: h.role === 'model' ? 'model' : 'user', parts: [{ text: h.text }] }))
      : [];
    contents.push({ role: 'user', parts: [{ text: message }] });

    const response = await fetch(`${GEMINI_URL}?key=${GEMINI_API_KEY}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents,
        systemInstruction: { parts: [{ text: SYSTEM_INSTRUCTION }] },
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error('Erreur API Gemini:', response.status, errText);
      return res.status(502).json({ error: "L'assistant IA est momentanément indisponible." });
    }

    const data = await response.json();
    const reply = data?.candidates?.[0]?.content?.parts?.map(p => p.text || '').join('') || '';

    if (!reply) {
      return res.status(502).json({ error: "Réponse vide de l'assistant." });
    }

    res.json({ reply });
  } catch (err) {
    console.error('Erreur serveur /api/chat:', err);
    res.status(500).json({ error: 'Erreur interne du serveur.' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Serveur démarré sur le port ${PORT}`);
});
